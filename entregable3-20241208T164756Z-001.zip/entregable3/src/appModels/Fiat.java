package appModels;

/**
 * Esta clase representa un tipo de moneda fiduciaria.
 */
public class Fiat extends Moneda {

    public Fiat(String nombre_Icono, String nombre, String nomenclatura, double valor_Dolar){
		super(nombre_Icono, nombre, nomenclatura, valor_Dolar);
	}
	
}
