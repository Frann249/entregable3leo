package app;

public enum Operacion {
	CREAR_MONEDA, LISTAR_MONEDAS, GENERAR_STOCK, LISTAR_STOCK, GENERAR_ACTIVOS_USER, LISTAR_ACTIVOS_USER, COMPRA_CRIPTO, SWAP, SALIR; 
 public String toString() {
	 return name();
 }
}
