package appDAO;

import appModels.Transaccion;

public interface TransaccionDAO {
	public boolean guardarTransaccion(Transaccion transaccion);
}
