package excepciones;

public class ExcepcionTerminosNoAceptados extends Exception {
    public ExcepcionTerminosNoAceptados(String mensaje) {
        super(mensaje);
    }
}