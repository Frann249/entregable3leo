package excepciones;

public class ExcepcionMontoInvalido extends Exception {
    public ExcepcionMontoInvalido(String mensaje) {
        super(mensaje);
    }
}