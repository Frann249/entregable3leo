package excepciones;

public class ExcepcionFondosInsuficientes extends Exception {
    public ExcepcionFondosInsuficientes(String mensaje) {
        super(mensaje);
    }
}